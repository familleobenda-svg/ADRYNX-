import re


def extraire_entites(sujet):

    entites = {
        "personnes": [],
        "lieux": [],
        "concepts": []
   
