from memoire import apprendre, chercher

print("===============================")
print("      ADRYNX AI ASSISTANT")
print("===============================")

while True:
    commande = input("\nADRYNX > ")

    if commande.startswith("apprends"):
        information = commande.replace("apprends ", "")
        apprendre("ADRYNX", information)

    elif commande.startswith("cherche"):
        sujet = commande.replace("cherche ", "")
        chercher(sujet)

    elif commande == "quitter":
        print("Arrêt ADRYNX AI")
        break

    else:
        print("Je n'ai pas encore appris cette commande.")
