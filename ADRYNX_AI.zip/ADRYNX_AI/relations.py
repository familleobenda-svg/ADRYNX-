import sqlite3


connexion = sqlite3.connect("connaissances.db")
curseur = connexion.cursor()


curseur.execute("""
CREATE TABLE IF NOT EXISTS relations(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    sujet TEXT,

    relation TEXT,

    objet TEXT
)
""")


connexion.commit()



def ajouter_relation(sujet, relation, objet):

    curseur.execute(
        """
        INSERT INTO relations
        (sujet, relation, objet)
        VALUES (?, ?, ?)
        """,
        (
            sujet,
            relation,
            objet
        )
    )

    connexion.commit()



def chercher_relations(sujet):

    curseur.execute(
        """
        SELECT relation, objet
        FROM relations
        WHERE sujet=?
        """,
        (sujet,)
    )

    resultats = curseur.fetchall()

    relations = []

    for relation, objet in resultats:

        relations.append({
            "relation": relation,
            "objet": objet
        })

    return relations



def nombre_relations():

    curseur.execute(
        "SELECT COUNT(*) FROM relations"
    )

    return curseur.fetchone()[0]
