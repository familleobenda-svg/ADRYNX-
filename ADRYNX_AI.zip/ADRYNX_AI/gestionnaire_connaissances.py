from faits import extraire_faits
from connaissances import enregistrer_personne
from entites import extraire_entites


def apprendre_depuis_reponse(analyse, reponse):

    if not reponse:
        return

    entites = extraire_entites(analyse["sujet"])

    if not entites["personnes"]:
        return

    nom = entites["personnes"][0]

    faits = extraire_faits(reponse)

    if len(faits) == 0:
        return

    enregistrer_personne(
        nom,
        faits
    )


def chercher_connaissances(analyse):

    from connaissances import chercher_personne

    entites = extraire_entites(analyse["sujet"])

    if not entites["personnes"]:
        return None

    return chercher_personne(
        entites["personnes"][0]
    )
