corrections = {
    "deni sassou nguesso": "denis sassou nguesso",
    "albert einstain": "albert einstein",
    "pythagor": "pythagore",
    "pyton": "python"
}


def corriger(sujet):

    sujet = sujet.lower().strip()

    if sujet in corrections:
        return corrections[sujet]

    return sujet
