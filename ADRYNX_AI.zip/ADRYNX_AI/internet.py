import requests
from bs4 import BeautifulSoup

print("Module Internet ADRYNX prêt.")


def rechercher(question):
    print("🔎 Recherche ADRYNX :", question)

    resultat = recherche_duckduckgo(question)

    if resultat != "Aucune information trouvée.":
        return resultat

    return recherche_wikipedia(question)


def recherche_duckduckgo(question):

    url = "https://api.duckduckgo.com/"

    params = {
        "q": question,
        "format": "json",
        "no_html": "1",
        "skip_disambig": "1",
        "kl": "fr-fr"
    }

    try:
        reponse = requests.get(
            url,
            params=params,
            headers={"User-Agent": "ADRYNX_AI/1.0"},
            timeout=10
        )

        donnees = reponse.json()

        if donnees.get("AbstractText"):
            return donnees["AbstractText"][:1000]

        return "Aucune information trouvée."

    except:
        return "Aucune information trouvée."


def recherche_wikipedia(question):

    url = "https://fr.wikipedia.org/w/api.php"

    params = {
        "action": "query",
        "format": "json",
        "prop": "extracts",
        "exintro": True,
        "explaintext": True,
        "titles": question
    }

    try:
        reponse = requests.get(
            url,
            params=params,
            headers={"User-Agent": "ADRYNX_AI/1.0"},
            timeout=10
        )

        donnees = reponse.json()

        pages = donnees["query"]["pages"]

        for page in pages.values():
            if "extract" in page:
                return page["extract"][:1000]

        return "Aucune information trouvée."

    except Exception as e:
        return f"Erreur recherche : {e}"
