import re
import unicodedata


def enlever_accents(texte):
    return "".join(
        c for c in unicodedata.normalize("NFD", texte)
        if unicodedata.category(c) != "Mn"
    )


def nettoyer(question):

    question = question.lower()

    # Uniformiser les apostrophes
    question = question.replace("’", "'")

    # Développer les expressions courantes
    remplacements = {
        "qu'est-ce qui": "questcequi",
        "qu'est-ce que": "questceque",
        "est-ce que": "estceque",
        "dit-on": "diton",
        "peut-on": "peuton",
        "a-t-il": "atil",
        "a-t-elle": "atelle"
    }

    for ancien, nouveau in remplacements.items():
        question = question.replace(ancien, nouveau)

    # Enlever les accents
    question = enlever_accents(question)

    # Remplacer les apostrophes restantes par un espace
    question = question.replace("'", " ")

    # Garder uniquement lettres, chiffres et espaces
    question = re.sub(r"[^a-z0-9 ]", " ", question)

    # Supprimer les espaces multiples
    question = re.sub(r"\s+", " ", question)

    return question.strip()
