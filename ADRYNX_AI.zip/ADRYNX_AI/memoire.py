import sqlite3
import re

connexion = sqlite3.connect("memoire.db")
curseur = connexion.cursor()

curseur.execute("""
CREATE TABLE IF NOT EXISTS connaissances (
    question TEXT PRIMARY KEY,
    reponse TEXT
)
""")

connexion.commit()


ERREURS = [
    "",
    None,
    "Aucune information trouvée.",
    "Je n'ai trouvé aucune information fiable."
]


def normaliser(question):

    question = question.lower()

    question = question.strip()

    question = re.sub(r"[?!.,]", "", question)

    question = " ".join(question.split())

    return question


def est_valide(reponse):

    if reponse in ERREURS:
        return False

    texte = str(reponse).lower()

    mots_interdits = [

        "httpsconnectionpool",

        "failed to resolve",

        "traceback",

        "exception",

        "erreur recherche",

        "aucune information",

        "nameresolutionerror"

    ]

    for mot in mots_interdits:

        if mot in texte:

            return False

    return True


def chercher(question):

    question = normaliser(question)

    curseur.execute(

        "SELECT reponse FROM connaissances WHERE question=?",

        (question,)

    )

    resultat = curseur.fetchone()

    if resultat:

        if est_valide(resultat[0]):

            return resultat[0]

    return None


def apprendre(question, reponse):

    if not est_valide(reponse):

        return

    question = normaliser(question)

    curseur.execute(

        "INSERT OR REPLACE INTO connaissances VALUES (?, ?)",

        (question, reponse)

    )

    connexion.commit()


def oublier(question):

    question = normaliser(question)

    curseur.execute(

        "DELETE FROM connaissances WHERE question=?",

        (question,)

    )

    connexion.commit()


def vider():

    curseur.execute(

        "DELETE FROM connaissances"

    )

    connexion.commit()


def nombre():

    curseur.execute(

        "SELECT COUNT(*) FROM connaissances"

    )

    return curseur.fetchone()[0]
