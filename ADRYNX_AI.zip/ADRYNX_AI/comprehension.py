from nettoyage import nettoyer
from intentions import detecter_intention
from extraction import construire_sujet, extraire_mots_cles


def comprendre_question(question):

    question_originale = question

    question_normalisee = nettoyer(question)

    intention = detecter_intention(question)

    sujet = construire_sujet(question)

    mots = extraire_mots_cles(question)

    return {

        "question_originale": question_originale,

        "question_normalisee": question_normalisee,

        "sujet": sujet,

        "intention": intention,

        "niveau": "normal",

        "mots": mots

    }
