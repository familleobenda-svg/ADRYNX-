from normalisation import normaliser_question
from comprehension import comprendre_question
from correction import corriger
from raisonnement import analyser
from entites import extraire_entites
from strategie import rechercher_intelligemment
from memoire import chercher, apprendre
from reponse import generer_reponse
from contexte import enregistrer, lire, remplacer_pronoms


def traiter_question(question):

    # 1. Utiliser le contexte pour les pronoms
    question = remplacer_pronoms(question)

    # 2. Normaliser
    question = normaliser_question(question)

    # 3. Vérifier la mémoire
    reponse = chercher(question)

    if reponse:
        print("🧠 Réponse trouvée dans la mémoire.")
        return reponse

    # 4. Comprendre
    analyse = comprendre_question(question)

    # 5. Corriger le sujet
    analyse["sujet"] = corriger(analyse["sujet"])

    # 6. Raisonnement
    analyse = analyser(analyse)

    # 7. Détection des entités
    entites = extraire_entites(analyse["sujet"])

    # 8. Enregistrer le contexte
    enregistrer(entites, question)

    print("🧠 Analyse :", analyse)
    print("🏷️ Entités :", entites)
    print("🧩 Contexte :", lire())

    # 9. Utiliser le meilleur sujet
    analyse["sujet"] = entites["sujet_principal"]

    # 10. Recherche
    resultat = rechercher_intelligemment(analyse)

    # 11. Générer réponse
    reponse = generer_reponse(analyse, resultat)

    # 12. Mettre à jour le contexte avec la réponse
    enregistrer(entites, question, reponse)

    # 13. Sauvegarder dans la mémoire
    if reponse not in [
        "",
        None,
        "Je n'ai trouvé aucune information fiable.",
        "Aucune information trouvée."
    ]:
        apprendre(question, reponse)

    return reponse


if __name__ == "__main__":

    while True:

        question = input("Vous : ")

        if question.lower() in ["exit", "quit"]:
            print("👋 ADRYNX arrêté.")
            break

        if question.strip() == "":
            print("🤖 ADRYNX : Pose une question.")
            continue

        reponse = traiter_question(question)

        print("🤖 ADRYNX :", reponse)
