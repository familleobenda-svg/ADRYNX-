import requests

print("Module Internet ADRYNX prêt.")


def rechercher(question):
    print("🔎 Recherche ADRYNX :", question)


def tester_internet():
    reponse = requests.get("https://www.google.com")
    print("🌐 Connexion Internet OK :", reponse.status_code)

def recuperer_page(url):
    reponse = requests.get(url)
    return reponse.text

from bs4 import BeautifulSoup


def extraire_texte(html):
    soup = BeautifulSoup(html, "html.parser")
    return soup.get_text(" ", strip=True)

def rechercher_web(sujet):
    url = "https://www.google.com/search?q=" + sujet.replace(" ", "+")
    return url

def obtenir_recherche(sujet):
    url = rechercher_web(sujet)
    return url

def lire_recherche(sujet):
    url = rechercher_web(sujet)
    page = recuperer_page(url)
    texte = extraire_texte(page)

    return texte
