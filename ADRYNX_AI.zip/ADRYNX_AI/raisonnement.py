import re


def analyser(analyse):

    sujet = analyse.get("sujet", "").lower()
    question = analyse.get("question_originale", "").lower()

    # -----------------------------
    # Détection du type de raisonnement
    # -----------------------------

    type_raisonnement = "internet"

    # Calcul simple
    if re.search(r"\d+\s*[\+\-\*/x×]\s*\d+", question):
        type_raisonnement = "calcul"

    # Âge
    elif "âge" in question or "age" in question:
        type_raisonnement = "age"

    # Définition
    elif question.startswith("qu'est-ce") or question.startswith("que signifie"):
        type_raisonnement = "definition"

    # Personne
    elif question.startswith("qui est"):
        type_raisonnement = "personne"

    # Date
    elif question.startswith("quand"):
        type_raisonnement = "date"

    # Lieu
    elif question.startswith("où") or question.startswith("ou"):
        type_raisonnement = "lieu"

    # Fonctionnement
    elif question.startswith("comment"):
        type_raisonnement = "fonctionnement"

    # Explication
    elif question.startswith("pourquoi"):
        type_raisonnement = "explication"

    # -----------------------------
    # Synonymes
    # -----------------------------

    synonymes = {
        "ia": "intelligence artificielle",
        "ai": "intelligence artificielle",
        "python": "langage de programmation python",
        "java": "langage de programmation java",
        "javascript": "langage de programmation javascript",
        "js": "javascript",
        "c++": "langage de programmation c++"
    }

    if sujet in synonymes:
        sujet = synonymes[sujet]

    analyse["sujet"] = sujet
    analyse["type_raisonnement"] = type_raisonnement

    return analyse
