import re


def extraire_faits(texte):

    if not texte:
        return {}

    faits = {}

    texte = str(texte)


    # -------------------------
    # Date de naissance
    # Exemples :
    # né le 23 novembre 1943
    # née le 12 mars 1990
    # -------------------------

    naissance = re.search(
        r"(?:né|née)\s+le\s+(\d{1,2}\s+\w+\s+\d{4})",
        texte,
        re.IGNORECASE
    )

    if naissance:

        faits["date_naissance"] = naissance.group(1)


    # -------------------------
    # Lieu de naissance
    # Exemple :
    # né le 23 novembre 1943 à Edou
    # -------------------------

    lieu = re.search(
        r"(?:né|née).*?\d{4}\s+à\s+([A-ZÀ-ÿ][A-Za-zÀ-ÿ\-]+)",
        texte
    )

    if lieu:

        faits["lieu_naissance"] = lieu.group(1)


    # -------------------------
    # Profession
    # Exemple :
    # est un militaire et homme d'État congolais
    # -------------------------

    profession = re.search(
        r"est\s+(?:un|une)\s+([^\.]+)",
        texte,
        re.IGNORECASE
    )

    if profession:

        faits["profession"] = profession.group(1).strip()


    # -------------------------
    # Nationalité
    # -------------------------

    nationalites = [
        "congolais",
        "congolaise",
        "français",
        "française",
        "américain",
        "américaine"
    ]

    texte_lower = texte.lower()

    for nationalite in nationalites:

        if nationalite in texte_lower:

            faits["nationalite"] = nationalite

            break


    return faits
