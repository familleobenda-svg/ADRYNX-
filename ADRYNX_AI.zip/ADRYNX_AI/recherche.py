def chercher(sujet):
    resultat = {
        "sujet": sujet,
        "source": "Recherche ADRYNX",
        "message": "Recherche prête pour analyse."
    }

    return resultat
