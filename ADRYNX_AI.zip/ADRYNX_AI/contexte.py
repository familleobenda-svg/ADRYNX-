contexte = {
    "personne": None,
    "lieu": None,
    "sujet": None,
    "question": None,
    "reponse": None
}


def enregistrer(entites, question=None, reponse=None):

    if entites.get("personnes"):
        contexte["personne"] = entites["personnes"][0]

    if entites.get("lieux"):
        contexte["lieu"] = entites["lieux"][0]

    if entites.get("sujet_principal"):
        contexte["sujet"] = entites["sujet_principal"]

    if question:
        contexte["question"] = question

    if reponse:
        contexte["reponse"] = reponse



def remplacer_pronoms(question):

    personne = contexte.get("personne")

    if not personne:
        return question


    texte = question.lower()


    # Formes avec trait d'union
    remplacements = [
        ("a-t-il", "a " + personne),
        ("est-il", "est " + personne),
        ("était-il", "était " + personne),
        ("etait-il", "etait " + personne),

        ("de lui", "de " + personne),
        ("pour lui", "pour " + personne),

        ("son âge", "l'âge de " + personne),
        ("son age", "l'âge de " + personne),

        ("sa profession", "la profession de " + personne),
        ("sa nationalité", "la nationalité de " + personne),

        ("il", personne),
        ("lui", personne),
        ("son", personne),
        ("sa", personne),
        ("ses", personne)
    ]


    for ancien, nouveau in remplacements:

        if ancien in texte:

            texte = texte.replace(
                ancien,
                nouveau
            )


    return texte



def lire():

    return contexte



def effacer():

    for cle in contexte:
        contexte[cle] = None
