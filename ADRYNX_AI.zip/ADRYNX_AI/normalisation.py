import re

# Corrections des erreurs fréquentes
CORRECTIONS = {
    "deni": "denis",
    "savone": "savorgnan",
    "decouverte": "découverte",
    "brazzaville": "brazzaville",
    "pythagor": "pythagore",
    "pyton": "python",
}


def normaliser_question(question):

    question = question.lower()

    # Supprimer la ponctuation
    question = re.sub(r"[?!.,;:]", "", question)

    # Séparer les mots
    mots = question.split()

    # Corriger les fautes connues
    mots_corriges = []

    for mot in mots:
        mots_corriges.append(CORRECTIONS.get(mot, mot))

    return " ".join(mots_corriges)
