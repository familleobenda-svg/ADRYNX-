import re

PERSONNES_CONNUS = {
    "albert einstein": "Albert Einstein",
    "denis sassou nguesso": "Denis Sassou Nguesso",
    "deni sassou nguesso": "Denis Sassou Nguesso",
    "pierre savorgnan de brazza": "Pierre Savorgnan de Brazza",
    "pierre savorgnan brazza": "Pierre Savorgnan de Brazza",
    "savorgnan de brazza": "Pierre Savorgnan de Brazza",
    "alan turing": "Alan Turing",
    "albert camus": "Albert Camus",
    "guido van rossum": "Guido van Rossum"
}

LIEUX_CONNUS = {
    "congo-brazzaville": "Congo-Brazzaville",
    "congo": "Congo",
    "france": "France",
    "angleterre": "Angleterre",
    "allemagne": "Allemagne",
    "indonésie": "Indonésie"
}


def extraire_entites(sujet):

    sujet = sujet.lower()

    entites = {
        "personnes": [],
        "lieux": [],
        "sujet_principal": sujet
    }

    for cle, nom in PERSONNES_CONNUS.items():
        if cle in sujet:
            entites["personnes"].append(nom)

    for cle, nom in LIEUX_CONNUS.items():
        if cle in sujet:
            entites["lieux"].append(nom)

    if entites["personnes"]:
        entites["sujet_principal"] = entites["personnes"][0]

    elif entites["lieux"]:
        entites["sujet_principal"] = entites["lieux"][0]

    return entites
