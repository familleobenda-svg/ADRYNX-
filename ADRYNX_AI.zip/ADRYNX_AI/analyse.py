def analyser(texte):
    phrases = texte.split(".")

    resume = []

    for phrase in phrases:
        phrase = phrase.strip()
        if phrase:
            resume.append(phrase)

        if len(resume) == 2:
            break

    return "Résumé : " + ". ".join(resume) + "."
