from nettoyage import nettoyer


INTENTIONS = {

    "questcequi": "explication",
    "questceque": "definition",

    "pourquoi": "explication",
    "comment": "fonctionnement",

    "qui est": "personne",
    "qui etait": "personne",
    "qui a": "personne",

    "ou": "lieu",
    "quand": "date",
    "combien": "quantite",

    "compare": "comparaison",
    "difference": "comparaison",

    "explique": "explication",
    "resume": "resume",

    "peuton": "possibilite",
    "estceque": "question",

    "diton": "explication"
}


def detecter_intention(question):

    texte = nettoyer(question)

    for expression in sorted(
        INTENTIONS,
        key=len,
        reverse=True
    ):

        if texte.startswith(expression):

            return INTENTIONS[expression]

    return "question"
