from comprehension import comprendre_question
from internet import recuperer_page, extraire_texte
from analyse import analyser


def repondre(question):
    sujet = comprendre_question(question)

    print(sujet)

    url = "https://www.example.com"
    page = recuperer_page(url)

    texte = extraire_texte(page)

    resume = analyser(texte)

    return resume
