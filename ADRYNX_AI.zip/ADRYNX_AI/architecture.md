# ADRYNX AI - Architecture

=========================================
1. POINT D'ENTRÉE
=========================================

orchestrateur.py

↓

reçoit la question

↓

normalisation.py

↓

comprehension.py

↓

raisonnement.py

↓

entites.py

↓

contexte.py

↓

decision.py

↓

reponse.py


=========================================
2. MÉMOIRE
=========================================

memoire.py

Base :

memoire.db

Stocke :

Question

↓

Réponse


=========================================
3. CONNAISSANCES
=========================================

connaissances.py

Base :

connaissances.db

Table :

personnes

Colonnes :

nom

date_naissance

profession

nationalite

lieu_naissance


=========================================
4. EXTRACTION
=========================================

faits.py

Transforme une biographie en :

date

profession

nationalité

lieu


=========================================
5. GESTIONNAIRE
=========================================

gestionnaire_connaissances.py

Relie :

faits.py

↓

connaissances.py


=========================================
6. RELATIONS
=========================================

relations.py

Table :

relations

sujet

relation

objet


Exemple :

Denis Sassou Nguesso

↓

né à

↓

Edou


=========================================
7. RAISONNEMENT
=========================================

raisonnement.py

Décide :

calcul

internet

question

personne

date

âge


=========================================
8. CALCUL
=========================================

calcul.py

Calculs

Âges

Opérations


=========================================
9. INTERNET
=========================================

internet.py

↓

DuckDuckGo

↓

Wikipedia


=========================================
10. CONTEXTE
=========================================

contexte.py

Retient :

personne

lieu

sujet

question

réponse

Permet :

Quel âge a-t-il ?

↓

Quel âge a Denis Sassou Nguesso ?


=========================================
11. STRATÉGIE
=========================================

strategie.py

Construit plusieurs recherches

Choisit la meilleure


=========================================
12. DÉCISION
=========================================

decision.py

Ordre :

1 Connaissances

↓

2 Mémoire

↓

3 Calcul

↓

4 Internet


=========================================
13. RÉPONSE
=========================================

reponse.py

Met en forme la réponse finale


=========================================
14. OBJECTIF ADRYNX
=========================================

Comprendre

↓

Raisonner

↓

Apprendre

↓

Mémoriser

↓

Réutiliser

↓

Évoluer
