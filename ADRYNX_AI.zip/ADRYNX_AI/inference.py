import re

from entites_db import chercher_entite


def nettoyer(texte):

    texte = texte.lower()

    texte = re.sub(r"[^a-z0-9àâäéèêëîïôöùûüç ]", " ", texte)

    texte = re.sub(r"\s+", " ", texte)

    return texte.strip()


def inferer(question):

    question_originale = question

    question = nettoyer(question)


    # ---------
    # Recherche d'une entité connue
    # ---------

    mots = question.split()

    meilleure = None

    for taille in range(len(mots), 0, -1):

        for debut in range(len(mots) - taille + 1):

            morceau = " ".join(
                mots[debut:debut + taille]
            )

            entite = chercher_entite(
                morceau.title()
            )

            if entite:

                meilleure = entite

                break

        if meilleure:

            break


    if meilleure is None:

        return None


    attributs = meilleure["attributs"]


    question = question_originale.lower()


    if "créateur" in question or "createur" in question:

        if "createur" in attributs:

            return (
                f"Le créateur de "
                f"{meilleure['nom']} est "
                f"{attributs['createur']}."
            )


    if "année" in question or "annee" in question:

        if "annee" in attributs:

            return (
                f"{meilleure['nom']} a été créé en "
                f"{attributs['annee']}."
            )


    if "type" in question:

        return (
            f"{meilleure['nom']} est un "
            f"{meilleure['type']}."
        )


    return None
