import sqlite3

connexion = sqlite3.connect("connaissances.db")
curseur = connexion.cursor()

curseur.execute("""
CREATE TABLE IF NOT EXISTS personnes(

    nom TEXT PRIMARY KEY,

    date_naissance TEXT,

    profession TEXT,

    nationalite TEXT,

    lieu_naissance TEXT
)
""")

connexion.commit()


def enregistrer_personne(nom, faits):

    curseur.execute("""

    INSERT OR REPLACE INTO personnes(

        nom,

        date_naissance,

        profession,

        nationalite,

        lieu_naissance

    )

    VALUES(?,?,?,?,?)

    """,(

        nom,

        faits.get("date_naissance"),

        faits.get("profession"),

        faits.get("nationalite"),

        faits.get("lieu_naissance")

    ))

    connexion.commit()


def chercher_personne(nom):

    curseur.execute(

        "SELECT * FROM personnes WHERE nom=?",

        (nom,)

    )

    resultat = curseur.fetchone()

    if resultat is None:

        return None

    return {

        "nom": resultat[0],

        "date_naissance": resultat[1],

        "profession": resultat[2],

        "nationalite": resultat[3],

        "lieu_naissance": resultat[4]

    }


def nombre_personnes():

    curseur.execute(

        "SELECT COUNT(*) FROM personnes"

    )

    return curseur.fetchone()[0]
