
from normalisation import normaliser_question
from comprehension import comprendre_question
from correction import corriger
from raisonnement import analyser
from entites import extraire_entites
from memoire import apprendre
from reponse import generer_reponse
from contexte import enregistrer, lire, remplacer_pronoms
from decision import decider


def traiter_question(question):

    # 1. Gestion du contexte
    question = remplacer_pronoms(question)

    # 2. Normalisation
    question = normaliser_question(question)

    # 3. Compréhension
    analyse = comprendre_question(question)

    # 4. Correction
    analyse["sujet"] = corriger(analyse["sujet"])

    # 5. Raisonnement
    analyse = analyser(analyse)

    # 6. Entités
    entites = extraire_entites(analyse["sujet"])

    # 7. Mémoire du contexte
    enregistrer(entites, question)

    print("🧠 Analyse :", analyse)
    print("🏷️ Entités :", entites)
    print("🧩 Contexte :", lire())


    # 8. Nouveau cerveau de décision ADRYNX V4
    choix = decider(analyse)

    print("⚙️ Décision :", choix["type"])


    # 9. Résultat choisi
    resultat = choix["resultat"]


    # 10. Réponse finale
    reponse = generer_reponse(
        analyse,
        resultat
    )


    # 11. Mise à jour contexte
    enregistrer(
        entites,
        question,
        reponse
    )


    # 12. Apprentissage
    if reponse not in [
        "",
        None,
        "Je n'ai trouvé aucune information fiable.",
        "Aucune information trouvée."
    ]:
        apprendre(
            question,
            reponse
        )


    return reponse



if __name__ == "__main__":

    while True:

        question = input("Vous : ")

        if question.lower() in ["exit", "quit"]:
            print("👋 ADRYNX arrêté.")
            break

        if question.strip() == "":
            continue

        reponse = traiter_question(question)

        print("🤖 ADRYNX :", reponse)