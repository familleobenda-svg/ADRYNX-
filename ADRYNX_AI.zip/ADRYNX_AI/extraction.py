from nettoyage import nettoyer

MOTS_INUTILES = {

    "qui","que","quoi","questcequi","questceque",
    "pourquoi","comment","ou","quand","combien",

    "est","etait","a","ont","avait","avoir",

    "le","la","les","un","une","des","du","de",

    "dans","sur","avec","sans","chez","par","pour",

    "explique","resume","compare",

    "estceque","diton","peuton",

    "il","elle","ils","elles","nous","vous","je","tu",

    "ce","cet","cette","ces"

}


def extraire_mots_cles(question):

    texte = nettoyer(question)

    mots = texte.split()

    resultat = []

    for mot in mots:

        if len(mot) <= 2:
            continue

        if mot in MOTS_INUTILES:
            continue

        if mot not in resultat:
            resultat.append(mot)

    return resultat


def construire_sujet(question):

    return " ".join(
        extraire_mots_cles(question)
    )
