from internet import rechercher


def supprimer_doublons(liste):

    resultat = []

    for element in liste:
        element = element.strip()

        if element and element not in resultat:
            resultat.append(element)

    return resultat


def construire_requetes(analyse):

    sujet = analyse["sujet"]

    intention = analyse["intention"]

    requetes = []

    requetes.append(sujet)

    if intention == "personne":
        requetes.append(sujet + " biographie")
        requetes.append(sujet + " wikipedia")

    elif intention == "explication":
        requetes.append(sujet + " définition")
        requetes.append(sujet + " explication")
        requetes.append(sujet + " causes")

    elif intention == "definition":
        requetes.append(sujet + " définition")
        requetes.append(sujet + " wikipedia")

    elif intention == "fonctionnement":
        requetes.append(sujet + " fonctionnement")
        requetes.append(sujet + " explication")

    elif intention == "comparaison":
        requetes.append(sujet + " comparaison")

    elif intention == "date":
        requetes.append(sujet + " date")
        requetes.append(sujet + " histoire")

    elif intention == "lieu":
        requetes.append(sujet + " localisation")
        requetes.append(sujet + " carte")

    requetes.append(sujet + " wikipedia")

    return supprimer_doublons(requetes)


def rechercher_intelligemment(analyse):

    requetes = construire_requetes(analyse)

    for requete in requetes:

        print("🔎 Recherche ADRYNX :", requete)

        resultat = rechercher(requete)

        if resultat:

            texte = resultat.lower()

            if "aucune information" in texte:
                continue

            if len(resultat.strip()) < 30:
                continue

            return resultat

    return "Je n'ai trouvé aucune information fiable."
