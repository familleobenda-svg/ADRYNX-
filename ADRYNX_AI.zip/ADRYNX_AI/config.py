NOM_IA = "ADRYNX"
VERSION = "1.0"

LANGUE = "fr"

MEMOIRE_ACTIVE = True
INTERNET_ACTIVE = True

print(f"{NOM_IA} v{VERSION} chargé.")
