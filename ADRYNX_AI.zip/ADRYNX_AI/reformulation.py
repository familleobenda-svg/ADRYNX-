import re


TRANSFORMATIONS = {
    "change nom famille": "changement de nom de famille",
    "change nom": "changement de nom",
    "enfant change": "enfant changement",
    "fait que": "raisons pour lesquelles",
    "a decouvert": "découverte de",
    "est ne": "biographie naissance de"
}


def nettoyer_texte(texte):

    texte = texte.lower()

    texte = re.sub(r"[?!.,;:]", "", texte)

    return " ".join(texte.split())


def reformuler(sujet):

    sujet = nettoyer_texte(sujet)

    recherches = []

    recherches.append(sujet)

    nouvelle = sujet

    for ancien, remplacement in TRANSFORMATIONS.items():

        if ancien in nouvelle:
            nouvelle = nouvelle.replace(
                ancien,
                remplacement
            )

    if nouvelle != sujet:
        recherches.append(nouvelle)


    # Ajouter des variantes générales

    recherches.append(
        sujet + " explication"
    )

    recherches.append(
        sujet + " causes"
    )

    recherches.append(
        sujet + " définition"
    )


    # Supprimer les doublons

    resultat = []

    for r in recherches:

        if r not in resultat:
            resultat.append(r)


    return resultat
