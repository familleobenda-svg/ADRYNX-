import sqlite3


connexion = sqlite3.connect("entites.db")
curseur = connexion.cursor()


curseur.execute("""
CREATE TABLE IF NOT EXISTS entites(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    nom TEXT UNIQUE,

    type TEXT,

    description TEXT
)
""")


curseur.execute("""
CREATE TABLE IF NOT EXISTS attributs(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    entite TEXT,

    cle TEXT,

    valeur TEXT
)
""")


connexion.commit()



def ajouter_entite(nom, type_entite, description=""):

    curseur.execute(
        """
        INSERT OR IGNORE INTO entites(
            nom,
            type,
            description
        )
        VALUES(?,?,?)
        """,
        (
            nom,
            type_entite,
            description
        )
    )

    connexion.commit()



def ajouter_attribut(entite, cle, valeur):

    curseur.execute(
        """
        INSERT INTO attributs(
            entite,
            cle,
            valeur
        )
        VALUES(?,?,?)
        """,
        (
            entite,
            cle,
            valeur
        )
    )

    connexion.commit()



def chercher_entite(nom):

    curseur.execute(
        """
        SELECT nom,type,description
        FROM entites
        WHERE nom=?
        """,
        (nom,)
    )

    resultat = curseur.fetchone()

    if resultat is None:
        return None

    curseur.execute(
        """
        SELECT cle,valeur
        FROM attributs
        WHERE entite=?
        """,
        (nom,)
    )

    attributs = {}

    for cle, valeur in curseur.fetchall():

        attributs[cle] = valeur

    return {

        "nom": resultat[0],

        "type": resultat[1],

        "description": resultat[2],

        "attributs": attributs

    }



def nombre_entites():

    curseur.execute(
        "SELECT COUNT(*) FROM entites"
    )

    return curseur.fetchone()[0]
