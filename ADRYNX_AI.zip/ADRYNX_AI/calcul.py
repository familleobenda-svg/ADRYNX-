import re
from datetime import datetime


MOIS = {
    "janvier": 1,
    "février": 2,
    "fevrier": 2,
    "mars": 3,
    "avril": 4,
    "mai": 5,
    "juin": 6,
    "juillet": 7,
    "août": 8,
    "aout": 8,
    "septembre": 9,
    "octobre": 10,
    "novembre": 11,
    "décembre": 12,
    "decembre": 12
}


def calculer_age(date_naissance):

    try:

        texte = date_naissance.lower()

        nombres = re.findall(r"\d+", texte)

        if len(nombres) < 2:
            return None

        jour = int(nombres[0])
        annee = int(nombres[-1])


        mois = None

        for nom, numero in MOIS.items():

            if nom in texte:

                mois = numero
                break


        if mois is None:
            return None


        naissance = datetime(
            annee,
            mois,
            jour
        )

        aujourd_hui = datetime.now()

        age = aujourd_hui.year - naissance.year


        if (
            aujourd_hui.month,
            aujourd_hui.day
        ) < (
            naissance.month,
            naissance.day
        ):
            age -= 1


        return age


    except Exception:

        return None



def calculer_operation(expression):

    try:

        expression = expression.replace("x", "*")

        return eval(
            expression,
            {
                "__builtins__": {}
            }
        )

    except Exception:

        return None
