import requests

print("Module Internet ADRYNX prêt.")


def rechercher(question):
    print("🔎 Recherche ADRYNX :", question)

    url = "https://api.duckduckgo.com/"

    params = {
        "q": question,
        "format": "json",
        "no_html": "1",
        "skip_disambig": "1",
        "kl": "fr-fr"
    }

    try:
        reponse = requests.get(
            url,
            params=params,
            headers={
                "User-Agent": "ADRYNX_AI/1.0"
            },
            timeout=10
        )

        donnees = reponse.json()

        if donnees.get("AbstractText"):
            return donnees["AbstractText"][:1000]

        if donnees.get("RelatedTopics"):
            return str(donnees["RelatedTopics"][0])[:1000]

        return "Aucune information trouvée."

    except Exception as e:
        return f"Erreur recherche : {e}"
