from memoire import chercher

from calcul import (
    calculer_operation,
    calculer_age
)

from strategie import rechercher_intelligemment

from gestionnaire_connaissances import (
    chercher_connaissances,
    apprendre_depuis_reponse
)

from inference import inferer


ERREURS = [
    "",
    None,
    "Aucune information trouvée.",
    "Je n'ai trouvé aucune information fiable."
]


def contient_calcul(question):

    return any(
        c in question
        for c in "+-*/x×"
    )


def extraire_operation(question):

    for mot in [
        "combien font",
        "calcule",
        "calcul"
    ]:

        question = question.lower().replace(
            mot,
            ""
        )

    question = question.replace(
        "fois",
        "x"
    )

    caracteres = "0123456789+-*/x×."

    return "".join(
        c for c in question
        if c in caracteres
    )


def decider(analyse):

    question = analyse["question_originale"]


    # 1 - INFÉRENCE

    resultat_inference = inferer(question)

    if resultat_inference:

        return {
            "type": "inference",
            "resultat": resultat_inference
        }


    # 2 - CONNAISSANCES STRUCTURÉES

    connaissances = chercher_connaissances(analyse)

    if connaissances:

        if (
            "age" in question.lower()
            or "âge" in question.lower()
        ):

            naissance = connaissances.get(
                "date_naissance"
            )

            if naissance:

                age = calculer_age(naissance)

                if age is not None:

                    return {
                        "type": "connaissances",
                        "resultat": f"Il a {age} ans."
                    }


    # 3 - MÉMOIRE

    souvenir = chercher(question)

    if souvenir not in ERREURS:

        apprendre_depuis_reponse(
            analyse,
            souvenir
        )

        return {
            "type": "memoire",
            "resultat": souvenir
        }


    # 4 - CALCUL

    if contient_calcul(question):

        operation = extraire_operation(question)

        resultat = calculer_operation(operation)

        if resultat is not None:

            return {
                "type": "calcul",
                "resultat": f"Le résultat est {resultat}"
            }


    # 5 - INTERNET

    resultat = rechercher_intelligemment(analyse)

    apprendre_depuis_reponse(
        analyse,
        resultat
    )

    return {
        "type": "internet",
        "resultat": resultat
    }
