def generer_reponse(analyse, resultat):

    intention = analyse.get("intention", "question")

    if resultat is None:
        return "Je n'ai trouvé aucune information fiable."

    resultat = str(resultat).strip()

    if resultat == "":
        return "Je n'ai trouvé aucune information fiable."

    if resultat in [
        "Je n'ai trouvé aucune information fiable.",
        "Aucune information trouvée."
    ]:
        return "Je n'ai trouvé aucune information fiable."

    reponses = {

        "personne":
            resultat,

        "question":
            resultat,

        "definition":
            "Définition :\n\n" + resultat,

        "explication":
            "Voici l'explication :\n\n" + resultat,

        "fonctionnement":
            "Voici comment cela fonctionne :\n\n" + resultat,

        "comparaison":
            "Voici la comparaison :\n\n" + resultat,

        "date":
            "Voici la date :\n\n" + resultat,

        "lieu":
            "Voici le lieu :\n\n" + resultat,

        "resume":
            "Résumé :\n\n" + resultat,

        "possibilite":
            resultat,

        "quantite":
            resultat

    }

    return reponses.get(intention, resultat)
